---
title: "Gel and Liquid BlackGlass"
number: "060"
part: 15
part_roman: XV
part_title: "BlackGlass Engineering Atlas"
part_slug: blackglass-atlas
accent: magenta
system: "BlackGlass Engineering Atlas"
summary: "Gel and Liquid BlackGlass belongs to the BlackGlass control layer, where physical form is treated as writable but not arbitrary. The important detail is the transition from accepted body-map change to physical restructuring, stabilization, diagnostics, and th…"
prev_url: "/plates/059-plate-state-blackglass/"
prev_title: "Plate-State BlackGlass"
next_url: "/plates/061-particulate-blackglass/"
next_title: "Particulate BlackGlass"
---

Gel and Liquid BlackGlass belongs to the BlackGlass control layer, where physical form is treated as writable but not arbitrary. The important detail is the transition from accepted body-map change to physical restructuring, stabilization, diagnostics, and the conditions that can interrupt or reject the change. A rewrite begins with an accepted target state, then allocates material and energy, isolates affected regions, performs structural changes, and hands fine integration to Vitrites. The Glassheart can delay, reject, or partially stage a change when the requested geometry conflicts with identity safeguards, available resources, local damage, or a previously locked trait. This keeps BlackGlass powerful without turning it into consequence-free magic.

### **SYSTEM SNAPSHOT**

| **FIELD**              | **BLACKGLASS**                                                                                                                                                                                  |
|------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **PRIMARY QUESTION**   | the transition from accepted body-map change to physical restructuring, stabilization, diagnostics, and the conditions that can interrupt or reject the change                                  |
| **CONTROL LAYER**      | Glassheart arbitration                                                                                                                                                                          |
| **CANON VARIABILITY**  | Depends on state transition, repair budget, local node health, and Glassheart acceptance.                                                                                                       |
| **RARITY INTERACTION** | Any open rarity unless the whole build becomes sufficiently complex; Unobtanium remains permission-locked.                                                                                      |
| **DESIGN TEST**        | If gel and liquid blackglass disappeared from a scene, would movement, maintenance, accessibility, behavior, or visual identity noticeably change? If not, it needs more concrete consequences. |

### **OPERATIONAL RULES**

- A Glassshift needs a target, resources, a rewrite path, and a stabilization phase; skipping one should create a specific complication.

- Identity safeguards outrank cosmetic convenience. BlackGlass should refuse or quarantine changes that would destroy protected continuity without an explicit canon reason.

- Temporary changes need a rollback plan and resource cost. Permanent changes need long-term integration into posture, nerves, maintenance, and daily life.

- Visible glow, cracking, fluidity, or particulate motion should indicate state and workload rather than appearing randomly.

### **CONTROL / CONSEQUENCE FLOW**

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>TRIGGER</strong></p>
<p><strong>intent / injury / environment</strong></p></th>
<th><p><strong>ARBITRATION</strong></p>
<p><strong>Glassheart acceptance</strong></p></th>
<th><p><strong>REWRITE</strong></p>
<p><strong>BlackGlass structure</strong></p></th>
<th><p><strong>STABILIZE</strong></p>
<p><strong>Vitrites + calibration</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

### **EDGE CASES TO KEEP CONSISTENT**

- A shift is accepted but pauses because the available repair budget is too low.

- Local BlackGlass enters protective quarantine while the rest of the body remains functional.

- A requested rollback restores shape but not immediately the old sensory calibration.

**Cross-reference:** Use the A-Z index plus Part 15 directory for adjacent systems. This plate is a reference expansion and does not override character-owner authority or the creator-locked Unobtanium boundary.

### Human Notes & Practical Detail
**Gel and Liquid BlackGlass** is one of those details that can look simple on a reference sheet and turn into a dozen small decisions the moment the character starts moving.

The useful questions here are **the accepted body map, Glassheart arbitration, rewrite state, material supply, and the point where a temporary change becomes stable anatomy**. That is the technical side, but it should show up in ordinary life instead of only in diagrams. With **Gel and Liquid BlackGlass**, practical details can include movement, maintenance, clothing, and ordinary social interaction. A character who has had the feature for years usually handles those things without thinking; somebody who acquired it recently may still misjudge space, overcorrect, or consciously plan movements that will eventually become automatic.

Decide what **Gel and Liquid BlackGlass** feels like from the inside. It might register as ordinary proprioception, pressure, a quiet digital position sense, background diagnostics, or almost nothing until something goes wrong. Useful warning signs for this feature include slower response, reduced precision, and temporary fallback behavior. Those signs do not need to mean catastrophic failure. Noxivitre systems usually degrade in layers, so reduced precision or a safer fallback state often appears before anything truly dangerous happens.

For artists and writers, give **Gel and Liquid BlackGlass** at least one repeatable visual or behavioral tell. Possibilities include subtle BlackGlass seams, visible nanite traffic under load, and a more compact resting state. Keep the tell consistent enough that it feels like the same body from scene to scene. Also test the feature somewhere inconvenient but mundane: a cramped vehicle, an unfamiliar bed, a clinic designed for fixed anatomy, or a crowded hallway. If the design still has a believable answer there—perhaps through sleep, movement, and clothing—the rule is doing real work instead of existing only for spectacle.

If a character breaks the normal version of **Gel and Liquid BlackGlass**, write down what is compensating for the exception and what tradeoff appears somewhere else. A failed rewrite can stop at a stable intermediate state; the system would rather pause than keep changing blindly. Rarity should still be judged from the whole build. A visually extreme version can remain inside the open tiers, including Mythic, when it does not use creator-reserved founder authority. Unobtanium is not a reward for having the loudest silhouette.

#### Questions worth answering

- What misconception about **Gel and Liquid BlackGlass** would the character be tired of correcting?
- How does **Gel and Liquid BlackGlass** affect clothing, furniture, sleep, travel, or personal space?
- What does **Gel and Liquid BlackGlass** feel like when nothing is wrong?

A technical plate for **Gel and Liquid BlackGlass** should be understandable on its own. Cross-references can add depth, but the reader should not have to chase three other sections just to learn what the system does, what supports it, and what a visible problem would look like.
