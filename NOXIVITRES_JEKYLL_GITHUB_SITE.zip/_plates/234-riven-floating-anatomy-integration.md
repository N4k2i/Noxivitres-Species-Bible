---
title: "Riven Floating-Anatomy Integration"
number: "234"
part: 18
part_roman: XVIII
part_title: "Generation Zero Advanced Atlas"
part_slug: founder-atlas
accent: violet
system: "Generation Zero Advanced Atlas"
summary: "Riven Floating-Anatomy Integration is documented as Generation-Zero canon rather than a generic permission for every Noxivitre. The focus is how apparently detached anatomy stays neurologically continuous through position tracking, sensory return, load estima…"
prev_url: "/plates/233-mirror-origin-lattice/"
prev_title: "Mirror Origin Lattice"
next_url: "/plates/235-blade-segmentation-integration/"
next_title: "Blade Segmentation Integration"
---

Riven Floating-Anatomy Integration is documented as Generation-Zero canon rather than a generic permission for every Noxivitre. The focus is how apparently detached anatomy stays neurologically continuous through position tracking, sensory return, load estimation, and BlackGlass/Vitrite bridge redundancy. Riven and Blade are the first Noxivitres and the first confirmed Unobtanium members, but founder status is not a shortcut that makes every one of their visible traits locked. Their six permanent arms, floating anatomy, segmentation, unusual faces, additional sensors, and other extreme features can have open analogues at lower tiers. What distinguishes founder-class Unobtanium is their Origin Glassheart architecture and ability to author new stable body-map pathways. Character-specific decisions remain with the respective owners.

### **SYSTEM SNAPSHOT**

| **FIELD**              | **FOUNDER**                                                                                                                                                                                              |
|------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **PRIMARY QUESTION**   | how apparently detached anatomy stays neurologically continuous through position tracking, sensory return, load estimation, and BlackGlass/Vitrite bridge redundancy                                     |
| **CONTROL LAYER**      | founder body map                                                                                                                                                                                         |
| **CANON VARIABILITY**  | Generation-Zero architecture is stable but unusually self-authoring; overuse still has real fatigue and error costs.                                                                                     |
| **RARITY INTERACTION** | Founder-class Unobtanium context. Character-specific details remain owner-controlled.                                                                                                                    |
| **DESIGN TEST**        | If riven floating-anatomy integration disappeared from a scene, would movement, maintenance, accessibility, behavior, or visual identity noticeably change? If not, it needs more concrete consequences. |

### **OPERATIONAL RULES**

- Riven is owned by @n4k2; Blade is owned by @altblade. Character-level canon changes require the relevant owner.

- A floating segment still needs continuous proprioception, load estimation, and a defined behavior when the bridge weakens or is obstructed.

- Keep the two founders mechanically distinct: Riven trends adaptive and continuity-oriented; Blade trends mirrored, segmented, and precision-oriented.

- Any future maturation must preserve identity continuity and previous consequences instead of resetting the characters whenever a new feature is added.

### **CONTROL / CONSEQUENCE FLOW**

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>PERSON</strong></p>
<p><strong>Riven or Blade</strong></p></th>
<th><p><strong>ORIGIN CORE</strong></p>
<p><strong>founder authorization</strong></p></th>
<th><p><strong>BODY MAP</strong></p>
<p><strong>new stable pathway</strong></p></th>
<th><p><strong>LIMITS</strong></p>
<p><strong>fatigue + owner canon</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

### **EDGE CASES TO KEEP CONSISTENT**

- Riven-specific behavior should never be generalized into a required species trait unless @n4k2 explicitly approves that canon expansion.

- A founder can author a new pathway and still decide not to use it because fatigue, risk, or personal preference matters.

- An open-species character may resemble a founder visually without gaining founder-only Origin Glassheart permissions.

**Cross-reference:** Use the A-Z index plus Part 18 directory for adjacent systems. This plate is a reference expansion and does not override character-owner authority or the creator-locked Unobtanium boundary.

### Human Notes & Practical Detail
The best way to understand **Riven Floating-Anatomy Integration** is to imagine the character dealing with it on a boring Tuesday, not only during a transformation scene.

The useful questions here are **Generation-Zero core architecture, founder-only body-map authoring, owner canon, fatigue limits, and the difference between precedent and a public trait list**. That is the technical side, but it should show up in ordinary life instead of only in diagrams. With **Riven Floating-Anatomy Integration**, practical details can include knowing where a detached part is without looking, charging or maintaining a separated segment, moving through narrow doors, and keeping safe distance from walls. A character who has had the feature for years usually handles those things without thinking; somebody who acquired it recently may still misjudge space, overcorrect, or consciously plan movements that will eventually become automatic.

Decide what **Riven Floating-Anatomy Integration** feels like from the inside. It might register as ordinary proprioception, pressure, a quiet digital position sense, background diagnostics, or almost nothing until something goes wrong. Useful warning signs for this feature include loss of independent motion while suspension remains intact, reduced fine sensation, and positional drift. Those signs do not need to mean catastrophic failure. Noxivitre systems usually degrade in layers, so reduced precision or a safer fallback state often appears before anything truly dangerous happens.

For artists and writers, give **Riven Floating-Anatomy Integration** at least one repeatable visual or behavioral tell. Possibilities include small correction pulses between body and segment, a faint nanite bridge that only appears under load, and the part moving closer to the body when bandwidth drops. Keep the tell consistent enough that it feels like the same body from scene to scene. Also test the feature somewhere inconvenient but mundane: a cramped vehicle, an unfamiliar bed, a clinic designed for fixed anatomy, or a crowded hallway. If the design still has a believable answer there—perhaps through keeping safe distance from walls, charging or maintaining a separated segment, and deciding how far the part is allowed to drift while relaxed—the rule is doing real work instead of existing only for spectacle.

If a character breaks the normal version of **Riven Floating-Anatomy Integration**, write down what is compensating for the exception and what tradeoff appears somewhere else. Founder capability still has costs. Riven and Blade can author pathways that later Noxivitres normally cannot, but fatigue, risk, preference, and owner canon still matter. Rarity should still be judged from the whole build. A visually extreme version can remain inside the open tiers, including Mythic, when it does not use creator-reserved founder authority. Unobtanium is not a reward for having the loudest silhouette.

#### Questions worth answering

- Does **Riven Floating-Anatomy Integration** behave differently during a Glassshift, active repair, or emotional stress?
- What misconception about **Riven Floating-Anatomy Integration** would the character be tired of correcting?
- What does **Riven Floating-Anatomy Integration** feel like when nothing is wrong?

A technical plate for **Riven Floating-Anatomy Integration** should be understandable on its own. Cross-references can add depth, but the reader should not have to chase three other sections just to learn what the system does, what supports it, and what a visible problem would look like.
