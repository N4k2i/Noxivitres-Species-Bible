---
title: "Thermal Adaptation"
number: "078"
part: 15
part_roman: XV
part_title: "BlackGlass Engineering Atlas"
part_slug: blackglass-atlas
accent: magenta
system: "BlackGlass Engineering Atlas"
summary: "Thermal Adaptation belongs to the BlackGlass control layer, where physical form is treated as writable but not arbitrary. The important detail is the practical canon behind thermal adaptation, including how it is represented in the body map, what system contr…"
prev_url: "/plates/077-environmental-adaptation-logic/"
prev_title: "Environmental Adaptation Logic"
next_url: "/plates/079-pressure-adaptation/"
next_title: "Pressure Adaptation"
---

Thermal Adaptation belongs to the BlackGlass control layer, where physical form is treated as writable but not arbitrary. The important detail is the practical canon behind thermal adaptation, including how it is represented in the body map, what system controls it, what can vary between individuals, and what consequences should remain visible in everyday scenes. A rewrite begins with an accepted target state, then allocates material and energy, isolates affected regions, performs structural changes, and hands fine integration to Vitrites. The Glassheart can delay, reject, or partially stage a change when the requested geometry conflicts with identity safeguards, available resources, local damage, or a previously locked trait. This keeps BlackGlass powerful without turning it into consequence-free magic.

### **SYSTEM SNAPSHOT**

| **FIELD**              | **BLACKGLASS**                                                                                                                                                                                                             |
|------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **PRIMARY QUESTION**   | the practical canon behind thermal adaptation, including how it is represented in the body map, what system controls it, what can vary between individuals, and what consequences should remain visible in everyday scenes |
| **CONTROL LAYER**      | Glassheart arbitration                                                                                                                                                                                                     |
| **CANON VARIABILITY**  | Depends on state transition, repair budget, local node health, and Glassheart acceptance.                                                                                                                                  |
| **RARITY INTERACTION** | Any open rarity unless the whole build becomes sufficiently complex; Unobtanium remains permission-locked.                                                                                                                 |
| **DESIGN TEST**        | If thermal adaptation disappeared from a scene, would movement, maintenance, accessibility, behavior, or visual identity noticeably change? If not, it needs more concrete consequences.                                   |

### **OPERATIONAL RULES**

- A Glassshift needs a target, resources, a rewrite path, and a stabilization phase; skipping one should create a specific complication.

- Identity safeguards outrank cosmetic convenience. BlackGlass should refuse or quarantine changes that would destroy protected continuity without an explicit canon reason.

- Temporary changes need a rollback plan and resource cost. Permanent changes need long-term integration into posture, nerves, maintenance, and daily life.

- Visible glow, cracking, fluidity, or particulate motion should indicate state and workload rather than appearing randomly.

### **CONTROL / CONSEQUENCE FLOW**

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>TRIGGER</strong></p>
<p><strong>intent / injury / environment</strong></p></th>
<th><p><strong>ARBITRATION</strong></p>
<p><strong>Glassheart acceptance</strong></p></th>
<th><p><strong>REWRITE</strong></p>
<p><strong>BlackGlass structure</strong></p></th>
<th><p><strong>STABILIZE</strong></p>
<p><strong>Vitrites + calibration</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

### **EDGE CASES TO KEEP CONSISTENT**

- A shift is accepted but pauses because the available repair budget is too low.

- Local BlackGlass enters protective quarantine while the rest of the body remains functional.

- A requested rollback restores shape but not immediately the old sensory calibration.

**Cross-reference:** Use the A-Z index plus Part 15 directory for adjacent systems. This plate is a reference expansion and does not override character-owner authority or the creator-locked Unobtanium boundary.

### Human Notes & Practical Detail
The short version is useful, but **Thermal Adaptation** becomes a lot easier to write once it is treated as part of somebody’s ordinary life.

The useful questions here are **load paths, range of motion, proprioception, attachment or suspension logic, and the way nearby structures make room for it**. That is the technical side, but it should show up in ordinary life instead of only in diagrams. With **Thermal Adaptation**, practical details can include ordinary social interaction, maintenance, movement, and privacy. A character who has had the feature for years usually handles those things without thinking; somebody who acquired it recently may still misjudge space, overcorrect, or consciously plan movements that will eventually become automatic.

Decide what **Thermal Adaptation** feels like from the inside. It might register as ordinary proprioception, pressure, a quiet digital position sense, background diagnostics, or almost nothing until something goes wrong. Useful warning signs for this feature include slower response, reduced precision, and temporary fallback behavior. Those signs do not need to mean catastrophic failure. Noxivitre systems usually degrade in layers, so reduced precision or a safer fallback state often appears before anything truly dangerous happens.

For artists and writers, give **Thermal Adaptation** at least one repeatable visual or behavioral tell. Possibilities include subtle BlackGlass seams, visible nanite traffic under load, and a more compact resting state. Keep the tell consistent enough that it feels like the same body from scene to scene. Also test the feature somewhere inconvenient but mundane: a cramped vehicle, an unfamiliar bed, a clinic designed for fixed anatomy, or a crowded hallway. If the design still has a believable answer there—perhaps through privacy, ordinary social interaction, and sleep—the rule is doing real work instead of existing only for spectacle.

If a character breaks the normal version of **Thermal Adaptation**, write down what is compensating for the exception and what tradeoff appears somewhere else. The safest fallback is usually a mechanically conservative posture or reduced range, not the anatomy vanishing for no reason. Rarity should still be judged from the whole build. A visually extreme version can remain inside the open tiers, including Mythic, when it does not use creator-reserved founder authority. Unobtanium is not a reward for having the loudest silhouette.

#### Questions worth answering

- How does **Thermal Adaptation** affect clothing, furniture, sleep, travel, or personal space?
- Does **Thermal Adaptation** behave differently during a Glassshift, active repair, or emotional stress?
- Which parts of **Thermal Adaptation** are automatic, and which can be deliberately controlled?

A technical plate for **Thermal Adaptation** should be understandable on its own. Cross-references can add depth, but the reader should not have to chase three other sections just to learn what the system does, what supports it, and what a visible problem would look like.
