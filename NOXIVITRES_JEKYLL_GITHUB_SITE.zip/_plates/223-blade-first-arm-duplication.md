---
title: "Blade First Arm Duplication"
number: "223"
part: 18
part_roman: XVIII
part_title: "Generation Zero Advanced Atlas"
part_slug: founder-atlas
accent: violet
system: "Generation Zero Advanced Atlas"
summary: "Blade First Arm Duplication is documented as Generation-Zero canon rather than a generic permission for every Noxivitre. The focus is Blade-specific founder anatomy while preserving @altblade as the authority over character-level canon and separating his foun…"
prev_url: "/plates/222-riven-first-arm-duplication/"
prev_title: "Riven First Arm Duplication"
next_url: "/plates/224-riven-second-arm-duplication/"
next_title: "Riven Second Arm Duplication"
---

Blade First Arm Duplication is documented as Generation-Zero canon rather than a generic permission for every Noxivitre. The focus is Blade-specific founder anatomy while preserving @altblade as the authority over character-level canon and separating his founder precedent from general open-species traits. Riven and Blade are the first Noxivitres and the first confirmed Unobtanium members, but founder status is not a shortcut that makes every one of their visible traits locked. Their six permanent arms, floating anatomy, segmentation, unusual faces, additional sensors, and other extreme features can have open analogues at lower tiers. What distinguishes founder-class Unobtanium is their Origin Glassheart architecture and ability to author new stable body-map pathways. Character-specific decisions remain with the respective owners.

### **SYSTEM SNAPSHOT**

| **FIELD**              | **FOUNDER**                                                                                                                                                                                       |
|------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **PRIMARY QUESTION**   | Blade-specific founder anatomy while preserving @altblade as the authority over character-level canon and separating his founder precedent from general open-species traits                       |
| **CONTROL LAYER**      | founder body map                                                                                                                                                                                  |
| **CANON VARIABILITY**  | Generation-Zero architecture is stable but unusually self-authoring; overuse still has real fatigue and error costs.                                                                              |
| **RARITY INTERACTION** | Founder-class Unobtanium context. Character-specific details remain owner-controlled.                                                                                                             |
| **DESIGN TEST**        | If blade first arm duplication disappeared from a scene, would movement, maintenance, accessibility, behavior, or visual identity noticeably change? If not, it needs more concrete consequences. |

### **OPERATIONAL RULES**

- Riven is owned by @n4k2; Blade is owned by @altblade. Character-level canon changes require the relevant owner.

- Founder-only mechanics are Origin Glassheart/body-map authoring mechanics, not ordinary multi-limb, floating, plated, segmented, or expressive traits.

- Keep the two founders mechanically distinct: Riven trends adaptive and continuity-oriented; Blade trends mirrored, segmented, and precision-oriented.

- Any future maturation must preserve identity continuity and previous consequences instead of resetting the characters whenever a new feature is added.

### **CONTROL / CONSEQUENCE FLOW**

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>PERSON</strong></p>
<p><strong>Riven or Blade</strong></p></th>
<th><p><strong>ORIGIN CORE</strong></p>
<p><strong>founder authorization</strong></p></th>
<th><p><strong>BODY MAP</strong></p>
<p><strong>new stable pathway</strong></p></th>
<th><p><strong>LIMITS</strong></p>
<p><strong>fatigue + owner canon</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

### **EDGE CASES TO KEEP CONSISTENT**

- Blade-specific behavior should never be generalized into a required species trait unless @altblade explicitly approves that canon expansion.

- A founder can author a new pathway and still decide not to use it because fatigue, risk, or personal preference matters.

- An open-species character may resemble a founder visually without gaining founder-only Origin Glassheart permissions.

**Cross-reference:** Use the A-Z index plus Part 18 directory for adjacent systems. This plate is a reference expansion and does not override character-owner authority or the creator-locked Unobtanium boundary.

### Human Notes & Practical Detail
The best way to understand **Blade First Arm Duplication** is to imagine the character dealing with it on a boring Tuesday, not only during a transformation scene.

The useful questions here are **Generation-Zero core architecture, founder-only body-map authoring, owner canon, fatigue limits, and the difference between precedent and a public trait list**. That is the technical side, but it should show up in ordinary life instead of only in diagrams. With **Blade First Arm Duplication**, practical details can include shoulder clearance, reaching across the torso without self-collision, deciding which hands carry weight, and sleeping without trapping a lower arm pair. A character who has had the feature for years usually handles those things without thinking; somebody who acquired it recently may still misjudge space, overcorrect, or consciously plan movements that will eventually become automatic.

Decide what **Blade First Arm Duplication** feels like from the inside. It might register as ordinary proprioception, pressure, a quiet digital position sense, background diagnostics, or almost nothing until something goes wrong. Useful warning signs for this feature include a copied limb defaulting to a neutral guarded pose, lag in duplicated shoulder control, and crossed proprioception between two hands. Those signs do not need to mean catastrophic failure. Noxivitre systems usually degrade in layers, so reduced precision or a safer fallback state often appears before anything truly dangerous happens.

For artists and writers, give **Blade First Arm Duplication** at least one repeatable visual or behavioral tell. Possibilities include different arm pairs settling at different resting heights, subtle nanite glow around duplicated sockets, and plates shifting to give the lower shoulders room. Keep the tell consistent enough that it feels like the same body from scene to scene. Also test the feature somewhere inconvenient but mundane: a cramped vehicle, an unfamiliar bed, a clinic designed for fixed anatomy, or a crowded hallway. If the design still has a believable answer there—perhaps through shoulder clearance, sleeve and jacket construction, and sleeping without trapping a lower arm pair—the rule is doing real work instead of existing only for spectacle.

If a character breaks the normal version of **Blade First Arm Duplication**, write down what is compensating for the exception and what tradeoff appears somewhere else. Founder capability still has costs. Riven and Blade can author pathways that later Noxivitres normally cannot, but fatigue, risk, preference, and owner canon still matter. Rarity should still be judged from the whole build. A visually extreme version can remain inside the open tiers, including Mythic, when it does not use creator-reserved founder authority. Unobtanium is not a reward for having the loudest silhouette.

#### Questions worth answering

- Does **Blade First Arm Duplication** behave differently during a Glassshift, active repair, or emotional stress?
- What does **Blade First Arm Duplication** feel like when nothing is wrong?
- How does **Blade First Arm Duplication** affect clothing, furniture, sleep, travel, or personal space?

A technical plate for **Blade First Arm Duplication** should be understandable on its own. Cross-references can add depth, but the reader should not have to chase three other sections just to learn what the system does, what supports it, and what a visible problem would look like.
