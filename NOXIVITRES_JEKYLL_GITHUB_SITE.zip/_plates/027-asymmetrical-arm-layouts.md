---
title: "Asymmetrical Arm Layouts"
number: "027"
part: 14
part_roman: XIV
part_title: "Visual Anatomy & Morphology Atlas"
part_slug: visual-atlas
accent: cyan
system: "Visual Anatomy & Morphology Atlas"
summary: "Asymmetrical Arm Layouts should read as working anatomy, not as an accessory pasted onto a generic base body. This plate focuses on the practical canon behind asymmetrical arm layouts, including how it is represented in the body map, what system controls it,…"
prev_url: "/plates/026-eight-plus-arm-reinforcement/"
prev_title: "Eight-Plus-Arm Reinforcement"
next_url: "/plates/028-floating-arm-bridge-geometry/"
next_title: "Floating Arm Bridge Geometry"
---

**Asymmetrical Arm Layouts** should read as working anatomy, not as an accessory pasted onto a generic base body. This plate focuses on the practical canon behind asymmetrical arm layouts, including how it is represented in the body map, what system controls it, what can vary between individuals, and what consequences should remain visible in everyday scenes. The working rule is that every visible structure has to connect to load paths, nerves or local controllers, maintenance access, and the accepted body map. BlackGlass can make unusual geometry possible, but it does not erase basic questions such as where force goes, how the individual knows where the part is, what happens when it collides with the environment, and how the rest of the body compensates. A design can be stylized while still answering those questions consistently.

### **SYSTEM SNAPSHOT**

| **FIELD**              | **ANATOMICAL**                                                                                                                                                                                                                   |
|------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **PRIMARY QUESTION**   | the practical canon behind asymmetrical arm layouts, including how it is represented in the body map, what system controls it, what can vary between individuals, and what consequences should remain visible in everyday scenes |
| **CONTROL LAYER**      | body-map geometry                                                                                                                                                                                                                |
| **CANON VARIABILITY**  | Usually stable once accepted by the body map; temporary states must be explicitly treated as temporary.                                                                                                                          |
| **RARITY INTERACTION** | Any open rarity unless the whole build becomes sufficiently complex; Unobtanium remains permission-locked.                                                                                                                       |
| **DESIGN TEST**        | If asymmetrical arm layouts disappeared from a scene, would movement, maintenance, accessibility, behavior, or visual identity noticeably change? If not, it needs more concrete consequences.                                   |

### **OPERATIONAL RULES**

- Show attachment, suspension, or bridge logic clearly enough that another artist can reproduce the body without guessing.

- Account for range of motion and self-collision; extra anatomy must have somewhere to go when the character sits, runs, curls up, or reaches across the torso.

- Give each major structure sensory and maintenance consequences. Decorative structures can be less mechanically demanding, but they still occupy space and affect silhouette.

- Treat clothing, furniture, doorways, beds, vehicles, and medical access as part of anatomy design, not afterthoughts.

### **CONTROL / CONSEQUENCE FLOW**

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>BODY MAP</strong></p>
<p><strong>expected geometry</strong></p></th>
<th><p><strong>LOCAL SUPPORT</strong></p>
<p><strong>bone / frame / nodes</strong></p></th>
<th><p><strong>CONTROL</strong></p>
<p><strong>nerves + Vitrites</strong></p></th>
<th><p><strong>ENVIRONMENT</strong></p>
<p><strong>movement + clearance</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

### **EDGE CASES TO KEEP CONSISTENT**

- Temporary numbness or positional drift after a major rewrite.

- A structure that fits standing posture but collides while sitting, sleeping, or using doors.

- Asymmetry caused by injury, intentional design, or incomplete stabilization.

**Cross-reference:** Use the A-Z index plus Part 14 directory for adjacent systems. This plate is a reference expansion and does not override character-owner authority or the creator-locked Unobtanium boundary.

### Human Notes & Practical Detail
The short version is useful, but **Asymmetrical Arm Layouts** becomes a lot easier to write once it is treated as part of somebody’s ordinary life.

The useful questions here are **load paths, range of motion, proprioception, attachment or suspension logic, and the way nearby structures make room for it**. That is the technical side, but it should show up in ordinary life instead of only in diagrams. With **Asymmetrical Arm Layouts**, practical details can include deciding which hands carry weight, shoulder clearance, sleeve and jacket construction, and reaching across the torso without self-collision. A character who has had the feature for years usually handles those things without thinking; somebody who acquired it recently may still misjudge space, overcorrect, or consciously plan movements that will eventually become automatic.

Decide what **Asymmetrical Arm Layouts** feels like from the inside. It might register as ordinary proprioception, pressure, a quiet digital position sense, background diagnostics, or almost nothing until something goes wrong. Useful warning signs for this feature include crossed proprioception between two hands, a copied limb defaulting to a neutral guarded pose, and one arm pair dropping to reduced precision. Those signs do not need to mean catastrophic failure. Noxivitre systems usually degrade in layers, so reduced precision or a safer fallback state often appears before anything truly dangerous happens.

For artists and writers, give **Asymmetrical Arm Layouts** at least one repeatable visual or behavioral tell. Possibilities include subtle nanite glow around duplicated sockets, different arm pairs settling at different resting heights, and plates shifting to give the lower shoulders room. Keep the tell consistent enough that it feels like the same body from scene to scene. Also test the feature somewhere inconvenient but mundane: a cramped vehicle, an unfamiliar bed, a clinic designed for fixed anatomy, or a crowded hallway. If the design still has a believable answer there—perhaps through reaching across the torso without self-collision, shoulder clearance, and sleeping without trapping a lower arm pair—the rule is doing real work instead of existing only for spectacle.

If a character breaks the normal version of **Asymmetrical Arm Layouts**, write down what is compensating for the exception and what tradeoff appears somewhere else. The safest fallback is usually a mechanically conservative posture or reduced range, not the anatomy vanishing for no reason. Rarity should still be judged from the whole build. A visually extreme version can remain inside the open tiers, including Mythic, when it does not use creator-reserved founder authority. Unobtanium is not a reward for having the loudest silhouette.

#### Questions worth answering

- What would a Noxivitre medic see about **Asymmetrical Arm Layouts** that an ordinary observer would miss?
- How does **Asymmetrical Arm Layouts** affect clothing, furniture, sleep, travel, or personal space?
- Which parts of **Asymmetrical Arm Layouts** are automatic, and which can be deliberately controlled?

A technical plate for **Asymmetrical Arm Layouts** should be understandable on its own. Cross-references can add depth, but the reader should not have to chase three other sections just to learn what the system does, what supports it, and what a visible problem would look like.
