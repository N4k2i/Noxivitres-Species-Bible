---
title: "Courier Nanites"
number: "115"
part: 16
part_roman: XVI
part_title: "Vitrite / Nanite Operations Atlas"
part_slug: nanite-atlas
accent: blue
system: "Vitrite / Nanite Operations Atlas"
summary: "Courier Nanites describes work performed by Vitrites as a colony rather than by a single central machine. The focus is the exact work performed by distributed Vitrites, how the colony communicates, what it can repair, and where its authority stops. Vitrites a…"
prev_url: "/plates/114-sensory-nanites/"
prev_title: "Sensory Nanites"
next_url: "/plates/116-guard-nanites/"
next_title: "Guard Nanites"
---

Courier Nanites describes work performed by Vitrites as a colony rather than by a single central machine. The focus is the exact work performed by distributed Vitrites, how the colony communicates, what it can repair, and where its authority stops. Vitrites are numerous, specialized, replaceable, and locally intelligent enough to keep a region functioning when communication is degraded, but they do not independently redefine personhood or rewrite the accepted body map. They maintain interfaces, carry signals, repair tissue and synthetic structures, calibrate floating anatomy, and continuously compare local sensor data against the Glassheart-approved model. Their limitations are as important as their capabilities: depleted reservoirs, interference, corrupted timing, or poor calibration should produce concrete symptoms.

### **SYSTEM SNAPSHOT**

| **FIELD**              | **VITRITE**                                                                                                                                                                           |
|------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **PRIMARY QUESTION**   | the exact work performed by distributed Vitrites, how the colony communicates, what it can repair, and where its authority stops                                                      |
| **CONTROL LAYER**      | Vitrite network                                                                                                                                                                       |
| **CANON VARIABILITY**  | Depends on reservoir depth, bridge quality, synchronization, and network redundancy.                                                                                                  |
| **RARITY INTERACTION** | Any open rarity unless the whole build becomes sufficiently complex; Unobtanium remains permission-locked.                                                                            |
| **DESIGN TEST**        | If courier nanites disappeared from a scene, would movement, maintenance, accessibility, behavior, or visual identity noticeably change? If not, it needs more concrete consequences. |

### **OPERATIONAL RULES**

- Nanites maintain approved anatomy; they do not casually invent new permanent anatomy without Glassheart-level authorization.

- Distributed control requires redundancy. Important functions should have at least one local fallback when the main network is delayed or damaged.

- Every high-bandwidth bridge has a calibration problem: latency, position drift, sensory mismatch, or reservoir depletion can become meaningful failure modes.

- Cybersecurity is biological safety. Authentication, privacy, and foreign-swarm detection belong in the same category as infection control.

### **CONTROL / CONSEQUENCE FLOW**

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>SENSE / COMMAND</strong></p>
<p><strong>local input</strong></p></th>
<th><p><strong>ROUTE</strong></p>
<p><strong>mesh + bridge</strong></p></th>
<th><p><strong>ACT</strong></p>
<p><strong>tissue / plate / tool</strong></p></th>
<th><p><strong>VERIFY</strong></p>
<p><strong>feedback + correction</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

### **EDGE CASES TO KEEP CONSISTENT**

- Reservoir depletion forces the colony to prioritize core repair over cosmetics or expression.

- Network timing drift creates clumsiness before any obvious structural damage appears.

- Foreign nanites are physically compatible but rejected because their credentials or body-map assumptions do not match.

**Cross-reference:** Use the A-Z index plus Part 16 directory for adjacent systems. This plate is a reference expansion and does not override character-owner authority or the creator-locked Unobtanium boundary.

### Human Notes & Practical Detail
For **Courier Nanites**, the species rules should answer the practical questions first and leave spectacle for when the story actually needs it.

The useful questions here are **local swarm authority, bandwidth, reservoir access, signal routing, heat, and what the Vitrites are allowed to change without asking the Glassheart**. That is the technical side, but it should show up in ordinary life instead of only in diagrams. With **Courier Nanites**, practical details can include maintenance, sleep, privacy, and ordinary social interaction. A character who has had the feature for years usually handles those things without thinking; somebody who acquired it recently may still misjudge space, overcorrect, or consciously plan movements that will eventually become automatic.

Decide what **Courier Nanites** feels like from the inside. It might register as ordinary proprioception, pressure, a quiet digital position sense, background diagnostics, or almost nothing until something goes wrong. Useful warning signs for this feature include reduced precision, slower response, and temporary fallback behavior. Those signs do not need to mean catastrophic failure. Noxivitre systems usually degrade in layers, so reduced precision or a safer fallback state often appears before anything truly dangerous happens.

For artists and writers, give **Courier Nanites** at least one repeatable visual or behavioral tell. Possibilities include subtle BlackGlass seams, visible nanite traffic under load, and a more compact resting state. Keep the tell consistent enough that it feels like the same body from scene to scene. Also test the feature somewhere inconvenient but mundane: a cramped vehicle, an unfamiliar bed, a clinic designed for fixed anatomy, or a crowded hallway. If the design still has a believable answer there—perhaps through movement, sleep, and ordinary social interaction—the rule is doing real work instead of existing only for spectacle.

If a character breaks the normal version of **Courier Nanites**, write down what is compensating for the exception and what tradeoff appears somewhere else. Local function can survive degraded network contact, but precision and repair speed usually drop before basic survival does. Rarity should still be judged from the whole build. A visually extreme version can remain inside the open tiers, including Mythic, when it does not use creator-reserved founder authority. Unobtanium is not a reward for having the loudest silhouette.

#### Questions worth answering

- What is the first small sign that **Courier Nanites** is overloaded, damaged, or badly calibrated?
- What would a Noxivitre medic see about **Courier Nanites** that an ordinary observer would miss?
- What does **Courier Nanites** feel like when nothing is wrong?

A technical plate for **Courier Nanites** should be understandable on its own. Cross-references can add depth, but the reader should not have to chase three other sections just to learn what the system does, what supports it, and what a visible problem would look like.
