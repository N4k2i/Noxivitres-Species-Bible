---
title: "The Species in One Sentence"
number: "001"
part: 1
part_roman: I
part_title: "Identity & Foundation"
part_slug: identity
accent: cyan
system: "Identity & Foundation"
summary: "The Species in One Sentence helps define identity, boundaries, and the rules that keep the species recognizable without making every character identical. It is part of the baseline rather than a hard ceiling, so later lore can add detail without needing to th…"
next_url: "/entries/002-the-three-sentence-baseline/"
next_title: "The Three-Sentence Baseline"
---
The Species in One Sentence helps define identity, boundaries, and the rules that keep the species recognizable without making every character identical. It is part of the baseline rather than a hard ceiling, so later lore can add detail without needing to throw out the whole species concept.

- Design around whether the trait can be voluntarily suppressed.

- Decide what clothing or equipment has to change around it.

- Account for how the individual learned to coordinate it.

- Extra anatomy needs room to move. Limb sockets, wings, tails, and floating pieces should be placed with actual posture and collision in mind.

- Unobtanium should remain special through lore and permission, not by banning ordinary creators from having fun anatomy.

In practice, this can show up through details like fractured or floating face plates, ear or horn structures that integrate with the skull rather than looking glued on, or temporary nanite scaffolding. None of those are mandatory; they are examples of how the same rule can produce different silhouettes while still reading as part of one species.

In-world, **The Species in One Sentence** is not something the character has to explain every time it appears. It becomes background life: movement, clothing, maintenance, and ordinary social interaction can all be affected without turning every scene into a biology lecture. The rule is here so those little consequences stay consistent when the story is busy talking about something else.

This is the normal version of **The Species in One Sentence**, not a ban on future exceptions. If a later character breaks the default, document what changed, what supports the exception, and whether the change is personal or actually updates species-wide canon.

### **DEEPER CANON**

For Noxivitres, the species in one sentence is treated as a real system rather than a decorative trait. It connects to shared identity, visual language, and canon boundary. The working substrate is the BlackGlass rewrite system and the body-map rules every Noxivitre carries. That means the feature should have a readable input, a physical or informational pathway, and a stable result; BlackGlass is flexible, but it is not an excuse for effects to happen with no internal reason. When a later writer expands the species in one sentence, the first question should be what part of the body map is being changed or interpreted, and the second should be what keeps that change stable after the dramatic moment is over.

The main failure state for the species in one sentence is a definition that becomes so broad that the species stops being recognizable, or so narrow that people cannot make interesting characters. Noxivitre biology usually tries to correct inconsistencies instead of immediately collapsing, so small errors can produce compensation: nanites reroute signals, BlackGlass reinforces weak structures, or the Glassheart temporarily limits a mutation until coordination catches up. That correction is not free. It can consume energy, create heat, reduce regeneration elsewhere, slow sensory processing, or force the individual to consciously manage something that would normally be automatic. These consequences are useful because they keep an extremely flexible species from becoming consequence-free while still allowing very strange bodies to function.

- Define the body-map entry for the species in one sentence before defining flashy secondary effects.

- Decide what keeps the feature stable while the individual is asleep, injured, distracted, or low on nanites.

### **BLACKGLASS & NANITE INTERACTION**

BlackGlass does not build **The Species in One Sentence** from a blank species template. It starts with the individual: their proportions, coloration, existing plating or fur, scars, learned movement, and the body map they already recognize as themselves. Vitrite swarms handle the fine integration work while the Glassheart checks whether the result still belongs to that person. That is why copied anatomy normally looks personal rather than generic. If **The Species in One Sentence** is duplicated or rebuilt, details such as a more compact resting state and subtle BlackGlass seams should still fit the owner’s established design language unless corruption or deliberate experimentation is the point of the scene.

Control can be distributed instead of centralized. For the species in one sentence, the Glassheart sets the high-level body-map state, local BlackGlass handles structural adaptation, and nearby Vitrite swarms perform thousands of small corrections every second. If one layer is interrupted, the others may keep the feature functioning in a degraded state rather than switching it completely off. This gives writers room for partial failures: a floating segment may stay suspended but lose fine sensation, a display may keep working while expression becomes delayed, or a duplicated limb may remain healthy while coordination becomes clumsy. Partial failure is usually more interesting than treating every problem as either perfect function or total shutdown.

- Keep original coloration and personal construction language when BlackGlass duplicates an existing structure unless corruption is specifically part of the story.

- Give partial failures a readable symptom instead of making every malfunction an instant catastrophic shutdown.

### **RARITY, DAILY LIFE & EDGE CASES**

For **The Species in One Sentence**, rarity should be assigned by the whole build rather than by how flashy this one feature looks. Common is the stable/simple end of the scale; Uncommon adds noticeable complexity; Rare permits major structural deviation; Legendary stacks several demanding systems; Mythic is the intentionally extreme open tier. Unobtanium is different because it is creator-locked for founder-class or canon-authority reasons, not because it has the biggest number of limbs. A public character can therefore have an outrageous version of **The Species in One Sentence** and still remain Mythic if the concept does not require reserved founder mechanics.

In everyday life, the species in one sentence matters through character identity, presentation, community expectations, and whether a person chooses to show or hide unusual traits. The most convincing Noxivitre designs show at least a few of those consequences even when nothing is going wrong. A practical reference sheet can note how another character can recognize a Noxivitre without relying on one exact silhouette. None of this has to become constant exposition in a story; it is background logic that lets a character move naturally and lets artists or writers answer small questions consistently. Edge cases are allowed, but an exception should state what rule it breaks, why BlackGlass can support it, and what new limitation or tradeoff appears because of that exception. Riven Solace and Blade are the canon reference point for the species in one sentence because they are Generation Zero: the first two Noxivitres. Riven entered that transition from an Uncommon Protogen baseline with concealed floating legs and tail, horns, and two ear pairs, while Blade entered from a much more ordinary Common Protogen baseline. Their different starting bodies make the pair unusually useful for separating inherited anatomy from genuinely Noxivitre-specific BlackGlass changes. When later lore is uncertain, the founders can be used as precedent without requiring every later Noxivitre to copy them.

- Classify the entire design, not one isolated trait; rarity measures complexity and BlackGlass intensity, not worth or combat power.

- Write at least one mundane consequence of the species in one sentence so the feature still feels real outside transformation scenes.

### **EXPANSION HOOKS**

- Design a Common interpretation and a Mythic interpretation of the same idea.

- Decide what the nanites do when the feature is damaged.

- Describe how the feature changes clothing, furniture, movement, or sleeping posture.

### Human Notes & Practical Detail
For **The Species in One Sentence**, the species rules should answer the practical questions first and leave spectacle for when the story actually needs it.

The useful questions here are **sensory filtering, body ownership, attention, learned movement, memory continuity, and the difference between technical integration and emotional familiarity**. That is the technical side, but it should show up in ordinary life instead of only in diagrams. With **The Species in One Sentence**, practical details can include sleep, maintenance, privacy, and movement. A character who has had the feature for years usually handles those things without thinking; somebody who acquired it recently may still misjudge space, overcorrect, or consciously plan movements that will eventually become automatic.

Decide what **The Species in One Sentence** feels like from the inside. It might register as ordinary proprioception, pressure, a quiet digital position sense, background diagnostics, or almost nothing until something goes wrong. Useful warning signs for this feature include extra heat or energy use, temporary fallback behavior, and slower response. Those signs do not need to mean catastrophic failure. Noxivitre systems usually degrade in layers, so reduced precision or a safer fallback state often appears before anything truly dangerous happens.

For artists and writers, give **The Species in One Sentence** at least one repeatable visual or behavioral tell. Possibilities include subtle BlackGlass seams, visible nanite traffic under load, and a more compact resting state. Keep the tell consistent enough that it feels like the same body from scene to scene. Also test the feature somewhere inconvenient but mundane: a cramped vehicle, an unfamiliar bed, a clinic designed for fixed anatomy, or a crowded hallway. If the design still has a believable answer there—perhaps through movement, ordinary social interaction, and clothing—the rule is doing real work instead of existing only for spectacle.

If a character breaks the normal version of **The Species in One Sentence**, write down what is compensating for the exception and what tradeoff appears somewhere else. The person’s sense of ownership matters. A technically healthy state can still feel wrong, and a strange-looking state can feel completely normal. Rarity should still be judged from the whole build. A visually extreme version can remain inside the open tiers, including Mythic, when it does not use creator-reserved founder authority. Unobtanium is not a reward for having the loudest silhouette.

#### Questions worth answering

- What is the first small sign that **The Species in One Sentence** is overloaded, damaged, or badly calibrated?
- What does **The Species in One Sentence** feel like when nothing is wrong?
- How does **The Species in One Sentence** affect clothing, furniture, sleep, travel, or personal space?
- Which parts of **The Species in One Sentence** are automatic, and which can be deliberately controlled?

#### Character-facing note

**The Species in One Sentence** can shape habits, accessibility needs, confidence, embarrassment, fashion, or body language, but it should not replace the character's personality. Noxivitres can have extremely different bodies without those bodies deciding morality, intelligence, social importance, or fighting ability. That separation is important to the open-species side of the canon.
