---
title: "BlackGlass Rejection"
number: "073"
part: 3
part_roman: III
part_title: "BlackGlass Biology"
part_slug: blackglass
accent: magenta
system: "BlackGlass Biology"
summary: "BlackGlass Rejection describes one way BlackGlass changes, protects, or destabilizes a body. The important rule is that BlackGlass uses an internal body map, so even bizarre changes usually have a readable cause and a consistent anatomical result."
prev_url: "/entries/072-contamination-and-transfer/"
prev_title: "Contamination and Transfer"
next_url: "/entries/074-runaway-glassshifts/"
next_title: "Runaway Glassshifts"
---
BlackGlass Rejection describes one way BlackGlass changes, protects, or destabilizes a body. The important rule is that BlackGlass uses an internal body map, so even bizarre changes usually have a readable cause and a consistent anatomical result.

- Design around how the individual learned to coordinate it.

- Decide how strangers read the trait at a glance.

- Account for how medical scans classify it.

- Extra anatomy needs room to move. Limb sockets, wings, tails, and floating pieces should be placed with actual posture and collision in mind.

- Unobtanium should remain special through lore and permission, not by banning ordinary creators from having fun anatomy.

In practice, this can show up through details like distinctive paw or hand construction, detached but synchronized anatomy, or body segments held together by a nanite bridge. None of those are mandatory; they are examples of how the same rule can produce different silhouettes while still reading as part of one species.

In-world, **BlackGlass Rejection** is not something the character has to explain every time it appears. It becomes background life: clothing, maintenance, ordinary social interaction, and movement can all be affected without turning every scene into a biology lecture. The rule is here so those little consequences stay consistent when the story is busy talking about something else.

This is the normal version of **BlackGlass Rejection**, not a ban on future exceptions. If a later character breaks the default, document what changed, what supports the exception, and whether the change is personal or actually updates species-wide canon.

### **DEEPER CANON**

A useful way to understand blackglass rejection is to separate what the character sees from what BlackGlass and the nanites are actually doing underneath. It connects to mutation triggers, body-map rewriting, stabilization, and long-term mutation memory. The working substrate is active BlackGlass, dormant BlackGlass, Vitrite support swarms, core signaling, and the individual’s existing anatomy template. That means the feature should have a readable input, a physical or informational pathway, and a stable result; BlackGlass is flexible, but it is not an excuse for effects to happen with no internal reason. When a later writer expands blackglass rejection, the first question should be what part of the body map is being changed or interpreted, and the second should be what keeps that change stable after the dramatic moment is over.

The main failure state for blackglass rejection is runaway rewriting, rejection, contradictory body maps, incomplete stabilization, or a Glassshift that keeps trying to solve a problem after the problem is gone. Noxivitre biology usually tries to correct inconsistencies instead of immediately collapsing, so small errors can produce compensation: nanites reroute signals, BlackGlass reinforces weak structures, or the Glassheart temporarily limits a mutation until coordination catches up. That correction is not free. It can consume energy, create heat, reduce regeneration elsewhere, slow sensory processing, or force the individual to consciously manage something that would normally be automatic. These consequences are useful because they keep an extremely flexible species from becoming consequence-free while still allowing very strange bodies to function.

- Define the body-map entry for blackglass rejection before defining flashy secondary effects.

- Decide what keeps the feature stable while the individual is asleep, injured, distracted, or low on nanites.

### **BLACKGLASS & NANITE INTERACTION**

BlackGlass does not build **BlackGlass Rejection** from a blank species template. It starts with the individual: their proportions, coloration, existing plating or fur, scars, learned movement, and the body map they already recognize as themselves. Vitrite swarms handle the fine integration work while the Glassheart checks whether the result still belongs to that person. That is why copied anatomy normally looks personal rather than generic. If **BlackGlass Rejection** is duplicated or rebuilt, details such as a more compact resting state and visible nanite traffic under load should still fit the owner’s established design language unless corruption or deliberate experimentation is the point of the scene.

Control can be distributed instead of centralized. For blackglass rejection, the Glassheart sets the high-level body-map state, local BlackGlass handles structural adaptation, and nearby Vitrite swarms perform thousands of small corrections every second. If one layer is interrupted, the others may keep the feature functioning in a degraded state rather than switching it completely off. This gives writers room for partial failures: a floating segment may stay suspended but lose fine sensation, a display may keep working while expression becomes delayed, or a duplicated limb may remain healthy while coordination becomes clumsy. Partial failure is usually more interesting than treating every problem as either perfect function or total shutdown.

- Keep original coloration and personal construction language when BlackGlass duplicates an existing structure unless corruption is specifically part of the story.

- Give partial failures a readable symptom instead of making every malfunction an instant catastrophic shutdown.

### **RARITY, DAILY LIFE & EDGE CASES**

For **BlackGlass Rejection**, rarity should be assigned by the whole build rather than by how flashy this one feature looks. Common is the stable/simple end of the scale; Uncommon adds noticeable complexity; Rare permits major structural deviation; Legendary stacks several demanding systems; Mythic is the intentionally extreme open tier. Unobtanium is different because it is creator-locked for founder-class or canon-authority reasons, not because it has the biggest number of limbs. A public character can therefore have an outrageous version of **BlackGlass Rejection** and still remain Mythic if the concept does not require reserved founder mechanics.

In everyday life, blackglass rejection matters through how someone plans around stress, repairs, medical scans, accidental triggers, body changes, and the possibility that yesterday’s anatomy is not exactly today’s. The most convincing Noxivitre designs show at least a few of those consequences even when nothing is going wrong. A practical reference sheet can note what changes first, what stays recognizable, how quickly the change stabilizes, and what evidence remains after the event. None of this has to become constant exposition in a story; it is background logic that lets a character move naturally and lets artists or writers answer small questions consistently. Edge cases are allowed, but an exception should state what rule it breaks, why BlackGlass can support it, and what new limitation or tradeoff appears because of that exception.

- Classify the entire design, not one isolated trait; rarity measures complexity and BlackGlass intensity, not worth or combat power.

- Write at least one mundane consequence of blackglass rejection so the feature still feels real outside transformation scenes.

### **EXPANSION HOOKS**

- Write a version that is subtle enough to hide and another that cannot realistically be concealed.

- Decide what the nanites do when the feature is damaged.

- Decide whether the feature changes rarity by itself or only when combined with other major traits.

### Human Notes & Practical Detail
The best way to understand **BlackGlass Rejection** is to imagine the character dealing with it on a boring Tuesday, not only during a transformation scene.

The useful questions here are **the accepted body map, Glassheart arbitration, rewrite state, material supply, and the point where a temporary change becomes stable anatomy**. That is the technical side, but it should show up in ordinary life instead of only in diagrams. With **BlackGlass Rejection**, practical details can include ordinary social interaction, movement, clothing, and maintenance. A character who has had the feature for years usually handles those things without thinking; somebody who acquired it recently may still misjudge space, overcorrect, or consciously plan movements that will eventually become automatic.

Decide what **BlackGlass Rejection** feels like from the inside. It might register as ordinary proprioception, pressure, a quiet digital position sense, background diagnostics, or almost nothing until something goes wrong. Useful warning signs for this feature include extra heat or energy use, temporary fallback behavior, and reduced precision. Those signs do not need to mean catastrophic failure. Noxivitre systems usually degrade in layers, so reduced precision or a safer fallback state often appears before anything truly dangerous happens.

For artists and writers, give **BlackGlass Rejection** at least one repeatable visual or behavioral tell. Possibilities include subtle BlackGlass seams, a more compact resting state, and visible nanite traffic under load. Keep the tell consistent enough that it feels like the same body from scene to scene. Also test the feature somewhere inconvenient but mundane: a cramped vehicle, an unfamiliar bed, a clinic designed for fixed anatomy, or a crowded hallway. If the design still has a believable answer there—perhaps through privacy, ordinary social interaction, and movement—the rule is doing real work instead of existing only for spectacle.

If a character breaks the normal version of **BlackGlass Rejection**, write down what is compensating for the exception and what tradeoff appears somewhere else. A failed rewrite can stop at a stable intermediate state; the system would rather pause than keep changing blindly. Rarity should still be judged from the whole build. A visually extreme version can remain inside the open tiers, including Mythic, when it does not use creator-reserved founder authority. Unobtanium is not a reward for having the loudest silhouette.

#### Questions worth answering

- Does **BlackGlass Rejection** behave differently during a Glassshift, active repair, or emotional stress?
- What misconception about **BlackGlass Rejection** would the character be tired of correcting?
- Which parts of **BlackGlass Rejection** are automatic, and which can be deliberately controlled?
- What does **BlackGlass Rejection** feel like when nothing is wrong?

#### Character-facing note

**BlackGlass Rejection** can shape habits, accessibility needs, confidence, embarrassment, fashion, or body language, but it should not replace the character's personality. Noxivitres can have extremely different bodies without those bodies deciding morality, intelligence, social importance, or fighting ability. That separation is important to the open-species side of the canon.
