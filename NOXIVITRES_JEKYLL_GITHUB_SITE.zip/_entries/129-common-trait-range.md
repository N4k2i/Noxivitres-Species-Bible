---
title: "Common Trait Range"
number: "129"
part: 6
part_roman: VI
part_title: "Rarity System"
part_slug: rarity
accent: gold
system: "Rarity System"
summary: "Common Trait Range is part of the rarity framework. Rarity measures how structurally unusual and BlackGlass-intensive a design is; it does not automatically decide strength, morality, status, intelligence, or how important the character is."
prev_url: "/entries/128-common-overview/"
prev_title: "Common Overview"
next_url: "/entries/130-common-example-builds/"
next_title: "Common Example Builds"
---
Common Trait Range is part of the rarity framework. Rarity measures how structurally unusual and BlackGlass-intensive a design is; it does not automatically decide strength, morality, status, intelligence, or how important the character is.

- Baseline or lightly mutated body plan

- Usually two arms and two legs

- Minor floating segments are fine

- Simple horns, tails, ears, armor, or face variants

- BlackGlass remains highly stable

For Common designs, the visual target is consistency before spectacle. A character can still be simple or complicated inside the tier; the rarity name mainly tells other creators how far the anatomy has moved from the stable baseline and how much BlackGlass is actively involved in maintaining it.

A Common character can still share traits with neighboring tiers. Reclassification should happen when the whole design crosses a structural threshold, not because one tiny accessory, color choice, or cosmetic feature got added. This keeps the ladder useful instead of turning it into a checklist where every horn costs one rarity point.

This is the normal version of **Common Trait Range**, not a ban on future exceptions. If a later character breaks the default, document what changed, what supports the exception, and whether the change is personal or actually updates species-wide canon.

### **DEEPER CANON**

In canon, common trait range sits inside the same body-map logic as every other Noxivitre feature. It connects to classification by structural complexity, BlackGlass intensity, and how far the body plan departs from the ordinary range. The working substrate is observable anatomy, stable mutation behavior, core architecture, documented Glassshift capacity, and the combination of major traits rather than one flashy detail. That means the feature should have a readable input, a physical or informational pathway, and a stable result; BlackGlass is flexible, but it is not an excuse for effects to happen with no internal reason. When a later writer expands common trait range, the first question should be what part of the body map is being changed or interpreted, and the second should be what keeps that change stable after the dramatic moment is over.

The main failure state for common trait range is treating rarity as a power score, social rank, moral value, or excuse to lock ordinary anatomy behind permissions. Noxivitre biology usually tries to correct inconsistencies instead of immediately collapsing, so small errors can produce compensation: nanites reroute signals, BlackGlass reinforces weak structures, or the Glassheart temporarily limits a mutation until coordination catches up. That correction is not free. It can consume energy, create heat, reduce regeneration elsewhere, slow sensory processing, or force the individual to consciously manage something that would normally be automatic. These consequences are useful because they keep an extremely flexible species from becoming consequence-free while still allowing very strange bodies to function.

- Define the body-map entry for common trait range before defining flashy secondary effects.

- Decide what keeps the feature stable while the individual is asleep, injured, distracted, or low on nanites.

### **BLACKGLASS & NANITE INTERACTION**

BlackGlass does not build **Common Trait Range** from a blank species template. It starts with the individual: their proportions, coloration, existing plating or fur, scars, learned movement, and the body map they already recognize as themselves. Vitrite swarms handle the fine integration work while the Glassheart checks whether the result still belongs to that person. That is why copied anatomy normally looks personal rather than generic. If **Common Trait Range** is duplicated or rebuilt, details such as a more compact resting state and subtle BlackGlass seams should still fit the owner’s established design language unless corruption or deliberate experimentation is the point of the scene.

Control can be distributed instead of centralized. For common trait range, the Glassheart sets the high-level body-map state, local BlackGlass handles structural adaptation, and nearby Vitrite swarms perform thousands of small corrections every second. If one layer is interrupted, the others may keep the feature functioning in a degraded state rather than switching it completely off. This gives writers room for partial failures: a floating segment may stay suspended but lose fine sensation, a display may keep working while expression becomes delayed, or a duplicated limb may remain healthy while coordination becomes clumsy. Partial failure is usually more interesting than treating every problem as either perfect function or total shutdown.

- Keep original coloration and personal construction language when BlackGlass duplicates an existing structure unless corruption is specifically part of the story.

- Give partial failures a readable symptom instead of making every malfunction an instant catastrophic shutdown.

### **RARITY, DAILY LIFE & EDGE CASES**

For **Common Trait Range**, rarity should be assigned by the whole build rather than by how flashy this one feature looks. Common is the stable/simple end of the scale; Uncommon adds noticeable complexity; Rare permits major structural deviation; Legendary stacks several demanding systems; Mythic is the intentionally extreme open tier. Unobtanium is different because it is creator-locked for founder-class or canon-authority reasons, not because it has the biggest number of limbs. A public character can therefore have an outrageous version of **Common Trait Range** and still remain Mythic if the concept does not require reserved founder mechanics.

In everyday life, common trait range matters through how people talk about rarity, whether they care about it at all, how records classify someone, and how to prevent a label from replacing the character’s actual personality. The most convincing Noxivitre designs show at least a few of those consequences even when nothing is going wrong. A practical reference sheet can note how a design is labeled consistently while still leaving room for exceptions, mixed traits, reclassification, and personal style. None of this has to become constant exposition in a story; it is background logic that lets a character move naturally and lets artists or writers answer small questions consistently. Edge cases are allowed, but an exception should state what rule it breaks, why BlackGlass can support it, and what new limitation or tradeoff appears because of that exception.

- Classify the entire design, not one isolated trait; rarity measures complexity and BlackGlass intensity, not worth or combat power.

- Write at least one mundane consequence of common trait range so the feature still feels real outside transformation scenes.

### **EXPANSION HOOKS**

- Decide whether the feature is congenital, constructed, acquired, or the result of a later Glassshift.

- Define what a medical scanner would call this feature.

- Describe how the feature changes clothing, furniture, movement, or sleeping posture.

### Human Notes & Practical Detail
A good version of **Common Trait Range** feels specific to the person wearing it. The system can be technically complicated without making the character talk like a manual.

The useful questions here are **whole-body complexity, dependency count, active BlackGlass load, stability, and whether the concept changes canon authority rather than merely appearance**. That is the technical side, but it should show up in ordinary life instead of only in diagrams. With **Common Trait Range**, practical details can include ordinary social interaction, sleep, maintenance, and movement. A character who has had the feature for years usually handles those things without thinking; somebody who acquired it recently may still misjudge space, overcorrect, or consciously plan movements that will eventually become automatic.

Decide what **Common Trait Range** feels like from the inside. It might register as ordinary proprioception, pressure, a quiet digital position sense, background diagnostics, or almost nothing until something goes wrong. Useful warning signs for this feature include temporary fallback behavior, slower response, and extra heat or energy use. Those signs do not need to mean catastrophic failure. Noxivitre systems usually degrade in layers, so reduced precision or a safer fallback state often appears before anything truly dangerous happens.

For artists and writers, give **Common Trait Range** at least one repeatable visual or behavioral tell. Possibilities include visible nanite traffic under load, subtle BlackGlass seams, and a more compact resting state. Keep the tell consistent enough that it feels like the same body from scene to scene. Also test the feature somewhere inconvenient but mundane: a cramped vehicle, an unfamiliar bed, a clinic designed for fixed anatomy, or a crowded hallway. If the design still has a believable answer there—perhaps through sleep, ordinary social interaction, and movement—the rule is doing real work instead of existing only for spectacle.

If a character breaks the normal version of **Common Trait Range**, write down what is compensating for the exception and what tradeoff appears somewhere else. A classification disagreement should be solved by examining system complexity, not by arguing over which design looks more impressive. Rarity should still be judged from the whole build. A visually extreme version can remain inside the open tiers, including Mythic, when it does not use creator-reserved founder authority. Unobtanium is not a reward for having the loudest silhouette.

#### Questions worth answering

- What does **Common Trait Range** feel like when nothing is wrong?
- What would a Noxivitre medic see about **Common Trait Range** that an ordinary observer would miss?
- What misconception about **Common Trait Range** would the character be tired of correcting?
- Does **Common Trait Range** behave differently during a Glassshift, active repair, or emotional stress?

#### Character-facing note

**Common Trait Range** can shape habits, accessibility needs, confidence, embarrassment, fashion, or body language, but it should not replace the character's personality. Noxivitres can have extremely different bodies without those bodies deciding morality, intelligence, social importance, or fighting ability. That separation is important to the open-species side of the canon.
