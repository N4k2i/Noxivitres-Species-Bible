---
title: "Privacy and Body Autonomy"
number: "222"
part: 9
part_roman: IX
part_title: "Culture & Society"
part_slug: culture
accent: amber
system: "Culture & Society"
summary: "Privacy and Body Autonomy is intentionally flexible because the species is not supposed to have one mandatory planet-wide culture. Communities can disagree, invent traditions, hide traits, celebrate mutations, or treat rarity as completely unimportant."
prev_url: "/entries/221-memorial-practices/"
prev_title: "Memorial Practices"
next_url: "/entries/223-consent-around-scanning-and-nanites/"
next_title: "Consent Around Scanning and Nanites"
---
Privacy and Body Autonomy is intentionally flexible because the species is not supposed to have one mandatory planet-wide culture. Communities can disagree, invent traditions, hide traits, celebrate mutations, or treat rarity as completely unimportant.

- Design around how medical scans classify it.

- Decide whether BlackGlass treats it as original anatomy or a later addition.

- Account for how strangers read the trait at a glance.

- Mutations should still obey the individual's body map unless the story explicitly establishes corruption or instability.

- If a trait is copied from another species concept, change its construction and reason for existing so it fits BlackGlass biology.

In practice, this can show up through details like asymmetrical glass growths, visible core-light through translucent BlackGlass, or subtle glitching around active mutations. None of those are mandatory; they are examples of how the same rule can produce different silhouettes while still reading as part of one species.

In-world, **Privacy and Body Autonomy** is not something the character has to explain every time it appears. It becomes background life: privacy, movement, sleep, and maintenance can all be affected without turning every scene into a biology lecture. The rule is here so those little consequences stay consistent when the story is busy talking about something else.

This is the normal version of **Privacy and Body Autonomy**, not a ban on future exceptions. If a later character breaks the default, document what changed, what supports the exception, and whether the change is personal or actually updates species-wide canon.

### **DEEPER CANON**

In canon, privacy and body autonomy sits inside the same body-map logic as every other Noxivitre feature. It connects to social meaning, consent, accommodation, community variation, and the ways people build traditions around mutable bodies without requiring one universal culture. The working substrate is families, friend groups, local communities, institutions, art, clothing, medicine, shared terminology, and personal choices. That means the feature should have a readable input, a physical or informational pathway, and a stable result; BlackGlass is flexible, but it is not an excuse for effects to happen with no internal reason. When a later writer expands privacy and body autonomy, the first question should be what part of the body map is being changed or interpreted, and the second should be what keeps that change stable after the dramatic moment is over.

The main failure state for privacy and body autonomy is turning one community’s habit into a biological law, treating rarity as caste, ignoring bodily autonomy, or assuming every Noxivitre has the same attitude toward mutation. Noxivitre biology usually tries to correct inconsistencies instead of immediately collapsing, so small errors can produce compensation: nanites reroute signals, BlackGlass reinforces weak structures, or the Glassheart temporarily limits a mutation until coordination catches up. That correction is not free. It can consume energy, create heat, reduce regeneration elsewhere, slow sensory processing, or force the individual to consciously manage something that would normally be automatic. These consequences are useful because they keep an extremely flexible species from becoming consequence-free while still allowing very strange bodies to function.

- Define the body-map entry for privacy and body autonomy before defining flashy secondary effects.

- Decide what keeps the feature stable while the individual is asleep, injured, distracted, or low on nanites.

### **BLACKGLASS & NANITE INTERACTION**

BlackGlass does not build **Privacy and Body Autonomy** from a blank species template. It starts with the individual: their proportions, coloration, existing plating or fur, scars, learned movement, and the body map they already recognize as themselves. Vitrite swarms handle the fine integration work while the Glassheart checks whether the result still belongs to that person. That is why copied anatomy normally looks personal rather than generic. If **Privacy and Body Autonomy** is duplicated or rebuilt, details such as subtle BlackGlass seams and visible nanite traffic under load should still fit the owner’s established design language unless corruption or deliberate experimentation is the point of the scene.

Control can be distributed instead of centralized. For privacy and body autonomy, the Glassheart sets the high-level body-map state, local BlackGlass handles structural adaptation, and nearby Vitrite swarms perform thousands of small corrections every second. If one layer is interrupted, the others may keep the feature functioning in a degraded state rather than switching it completely off. This gives writers room for partial failures: a floating segment may stay suspended but lose fine sensation, a display may keep working while expression becomes delayed, or a duplicated limb may remain healthy while coordination becomes clumsy. Partial failure is usually more interesting than treating every problem as either perfect function or total shutdown.

- Keep original coloration and personal construction language when BlackGlass duplicates an existing structure unless corruption is specifically part of the story.

- Give partial failures a readable symptom instead of making every malfunction an instant catastrophic shutdown.

### **RARITY, DAILY LIFE & EDGE CASES**

For **Privacy and Body Autonomy**, rarity should be assigned by the whole build rather than by how flashy this one feature looks. Common is the stable/simple end of the scale; Uncommon adds noticeable complexity; Rare permits major structural deviation; Legendary stacks several demanding systems; Mythic is the intentionally extreme open tier. Unobtanium is different because it is creator-locked for founder-class or canon-authority reasons, not because it has the biggest number of limbs. A public character can therefore have an outrageous version of **Privacy and Body Autonomy** and still remain Mythic if the concept does not require reserved founder mechanics.

In everyday life, privacy and body autonomy matters through names, clothes, jokes, relationships, celebrations, accessibility, etiquette, art, work, and whether someone treats a Glassshift as exciting, annoying, frightening, or just normal. The most convincing Noxivitre designs show at least a few of those consequences even when nothing is going wrong. A practical reference sheet can note who gets to decide what a trait means, what is considered private, which accommodations become ordinary, and how different communities disagree without breaking canon. None of this has to become constant exposition in a story; it is background logic that lets a character move naturally and lets artists or writers answer small questions consistently. Edge cases are allowed, but an exception should state what rule it breaks, why BlackGlass can support it, and what new limitation or tradeoff appears because of that exception.

- Classify the entire design, not one isolated trait; rarity measures complexity and BlackGlass intensity, not worth or combat power.

- Write at least one mundane consequence of privacy and body autonomy so the feature still feels real outside transformation scenes.

### **EXPANSION HOOKS**

- Decide whether the feature changes rarity by itself or only when combined with other major traits.

- Write one example of the trait on a calm character and one on a stressed character.

- Give the trait one practical downside that is not just 'it hurts.'

### Human Notes & Practical Detail
The short version is useful, but **Privacy and Body Autonomy** becomes a lot easier to write once it is treated as part of somebody’s ordinary life.

The useful questions here are **load paths, range of motion, proprioception, attachment or suspension logic, and the way nearby structures make room for it**. That is the technical side, but it should show up in ordinary life instead of only in diagrams. With **Privacy and Body Autonomy**, practical details can include movement, privacy, maintenance, and ordinary social interaction. A character who has had the feature for years usually handles those things without thinking; somebody who acquired it recently may still misjudge space, overcorrect, or consciously plan movements that will eventually become automatic.

Decide what **Privacy and Body Autonomy** feels like from the inside. It might register as ordinary proprioception, pressure, a quiet digital position sense, background diagnostics, or almost nothing until something goes wrong. Useful warning signs for this feature include slower response, temporary fallback behavior, and reduced precision. Those signs do not need to mean catastrophic failure. Noxivitre systems usually degrade in layers, so reduced precision or a safer fallback state often appears before anything truly dangerous happens.

For artists and writers, give **Privacy and Body Autonomy** at least one repeatable visual or behavioral tell. Possibilities include subtle BlackGlass seams, a more compact resting state, and visible nanite traffic under load. Keep the tell consistent enough that it feels like the same body from scene to scene. Also test the feature somewhere inconvenient but mundane: a cramped vehicle, an unfamiliar bed, a clinic designed for fixed anatomy, or a crowded hallway. If the design still has a believable answer there—perhaps through movement, ordinary social interaction, and clothing—the rule is doing real work instead of existing only for spectacle.

If a character breaks the normal version of **Privacy and Body Autonomy**, write down what is compensating for the exception and what tradeoff appears somewhere else. The safest fallback is usually a mechanically conservative posture or reduced range, not the anatomy vanishing for no reason. Rarity should still be judged from the whole build. A visually extreme version can remain inside the open tiers, including Mythic, when it does not use creator-reserved founder authority. Unobtanium is not a reward for having the loudest silhouette.

#### Questions worth answering

- Does **Privacy and Body Autonomy** behave differently during a Glassshift, active repair, or emotional stress?
- What misconception about **Privacy and Body Autonomy** would the character be tired of correcting?
- How does **Privacy and Body Autonomy** affect clothing, furniture, sleep, travel, or personal space?
- What does **Privacy and Body Autonomy** feel like when nothing is wrong?

#### Character-facing note

**Privacy and Body Autonomy** can shape habits, accessibility needs, confidence, embarrassment, fashion, or body language, but it should not replace the character's personality. Noxivitres can have extremely different bodies without those bodies deciding morality, intelligence, social importance, or fighting ability. That separation is important to the open-species side of the canon.
