---
title: "Eight-Plus-Arm Builds"
number: "104"
part: 5
part_roman: V
part_title: "Morphology & Trait Catalog"
part_slug: morphology
accent: violet
system: "Morphology & Trait Catalog"
summary: "Eight-Plus-Arm Builds is a morphology option rather than a mandatory species trait. It should still look BlackGlass-built: the joints, attachment points, floating gaps, plating, and mutation seams should make the feature feel native to the species instead of…"
prev_url: "/entries/103-six-arm-builds/"
prev_title: "Six-Arm Builds"
next_url: "/entries/105-asymmetrical-limb-counts/"
next_title: "Asymmetrical Limb Counts"
---
Eight-Plus-Arm Builds is a morphology option rather than a mandatory species trait. It should still look BlackGlass-built: the joints, attachment points, floating gaps, plating, and mutation seams should make the feature feel native to the species instead of pasted on.

- Design around what maintenance the nanites perform.

- Decide how strangers read the trait at a glance.

- Account for how the individual learned to coordinate it.

- A cool visual does not automatically need a higher rarity; rarity should track structural complexity, not color or fashion.

- If a trait is copied from another species concept, change its construction and reason for existing so it fits BlackGlass biology.

In practice, this can show up through details like distinctive paw or hand construction, clean silhouettes even when the anatomy is complex, or nonuniform crystalline surfaces. None of those are mandatory; they are examples of how the same rule can produce different silhouettes while still reading as part of one species.

In-world, **Eight-Plus-Arm Builds** is not something the character has to explain every time it appears. It becomes background life: sleeve and jacket construction, sleeping without trapping a lower arm pair, reaching across the torso without self-collision, and shoulder clearance can all be affected without turning every scene into a biology lecture. The rule is here so those little consequences stay consistent when the story is busy talking about something else.

This is the normal version of **Eight-Plus-Arm Builds**, not a ban on future exceptions. If a later character breaks the default, document what changed, what supports the exception, and whether the change is personal or actually updates species-wide canon.

### **DEEPER CANON**

In canon, eight-plus-arm builds sits inside the same body-map logic as every other Noxivitre feature. It connects to body geometry, socket placement, balance, collision clearance, coordination, and BlackGlass-supported structural variation. The working substrate is the body map, skeletal or synthetic anchors, nerves, actuators, nanite bridges, and adaptive tissue around the changed body plan. That means the feature should have a readable input, a physical or informational pathway, and a stable result; BlackGlass is flexible, but it is not an excuse for effects to happen with no internal reason. When a later writer expands eight-plus-arm builds, the first question should be what part of the body map is being changed or interpreted, and the second should be what keeps that change stable after the dramatic moment is over.

The main failure state for eight-plus-arm builds is a cool-looking design that has no room to move, duplicated structures that collide with each other, poor center of mass, or too many systems competing for the same space. Noxivitre biology usually tries to correct inconsistencies instead of immediately collapsing, so small errors can produce compensation: nanites reroute signals, BlackGlass reinforces weak structures, or the Glassheart temporarily limits a mutation until coordination catches up. That correction is not free. It can consume energy, create heat, reduce regeneration elsewhere, slow sensory processing, or force the individual to consciously manage something that would normally be automatic. These consequences are useful because they keep an extremely flexible species from becoming consequence-free while still allowing very strange bodies to function.

- Define the body-map entry for eight-plus-arm builds before defining flashy secondary effects.

- Decide what keeps the feature stable while the individual is asleep, injured, distracted, or low on nanites.

### **BLACKGLASS & NANITE INTERACTION**

BlackGlass does not build **Eight-Plus-Arm Builds** from a blank species template. It starts with the individual: their proportions, coloration, existing plating or fur, scars, learned movement, and the body map they already recognize as themselves. Vitrite swarms handle the fine integration work while the Glassheart checks whether the result still belongs to that person. That is why copied anatomy normally looks personal rather than generic. If **Eight-Plus-Arm Builds** is duplicated or rebuilt, details such as different arm pairs settling at different resting heights and subtle nanite glow around duplicated sockets should still fit the owner’s established design language unless corruption or deliberate experimentation is the point of the scene.

Control can be distributed instead of centralized. For eight-plus-arm builds, the Glassheart sets the high-level body-map state, local BlackGlass handles structural adaptation, and nearby Vitrite swarms perform thousands of small corrections every second. If one layer is interrupted, the others may keep the feature functioning in a degraded state rather than switching it completely off. This gives writers room for partial failures: a floating segment may stay suspended but lose fine sensation, a display may keep working while expression becomes delayed, or a duplicated limb may remain healthy while coordination becomes clumsy. Partial failure is usually more interesting than treating every problem as either perfect function or total shutdown.

- Keep original coloration and personal construction language when BlackGlass duplicates an existing structure unless corruption is specifically part of the story.

- Give partial failures a readable symptom instead of making every malfunction an instant catastrophic shutdown.

### **RARITY, DAILY LIFE & EDGE CASES**

For **Eight-Plus-Arm Builds**, rarity should be assigned by the whole build rather than by how flashy this one feature looks. Common is the stable/simple end of the scale; Uncommon adds noticeable complexity; Rare permits major structural deviation; Legendary stacks several demanding systems; Mythic is the intentionally extreme open tier. Unobtanium is different because it is creator-locked for founder-class or canon-authority reasons, not because it has the biggest number of limbs. A public character can therefore have an outrageous version of **Eight-Plus-Arm Builds** and still remain Mythic if the concept does not require reserved founder mechanics.

In everyday life, eight-plus-arm builds matters through doors, chairs, beds, vehicles, hugs, carrying objects, sports, workspaces, and learning where every new body part is without staring at it. The most convincing Noxivitre designs show at least a few of those consequences even when nothing is going wrong. A practical reference sheet can note stance, gait, reach, turning radius, resting position, clothing cuts, furniture fit, and how the form looks when actually moving instead of posing. None of this has to become constant exposition in a story; it is background logic that lets a character move naturally and lets artists or writers answer small questions consistently. Edge cases are allowed, but an exception should state what rule it breaks, why BlackGlass can support it, and what new limitation or tradeoff appears because of that exception.

- Classify the entire design, not one isolated trait; rarity measures complexity and BlackGlass intensity, not worth or combat power.

- Write at least one mundane consequence of eight-plus-arm builds so the feature still feels real outside transformation scenes.

### **EXPANSION HOOKS**

- Decide what the nanites do when the feature is damaged.

- Decide whether the feature changes rarity by itself or only when combined with other major traits.

- Design a Common interpretation and a Mythic interpretation of the same idea.

### Human Notes & Practical Detail
The short version is useful, but **Eight-Plus-Arm Builds** becomes a lot easier to write once it is treated as part of somebody’s ordinary life.

The useful questions here are **load paths, range of motion, proprioception, attachment or suspension logic, and the way nearby structures make room for it**. That is the technical side, but it should show up in ordinary life instead of only in diagrams. With **Eight-Plus-Arm Builds**, practical details can include sleeping without trapping a lower arm pair, reaching across the torso without self-collision, deciding which hands carry weight, and sleeve and jacket construction. A character who has had the feature for years usually handles those things without thinking; somebody who acquired it recently may still misjudge space, overcorrect, or consciously plan movements that will eventually become automatic.

Decide what **Eight-Plus-Arm Builds** feels like from the inside. It might register as ordinary proprioception, pressure, a quiet digital position sense, background diagnostics, or almost nothing until something goes wrong. Useful warning signs for this feature include one arm pair dropping to reduced precision, lag in duplicated shoulder control, and crossed proprioception between two hands. Those signs do not need to mean catastrophic failure. Noxivitre systems usually degrade in layers, so reduced precision or a safer fallback state often appears before anything truly dangerous happens.

For artists and writers, give **Eight-Plus-Arm Builds** at least one repeatable visual or behavioral tell. Possibilities include plates shifting to give the lower shoulders room, different arm pairs settling at different resting heights, and subtle nanite glow around duplicated sockets. Keep the tell consistent enough that it feels like the same body from scene to scene. Also test the feature somewhere inconvenient but mundane: a cramped vehicle, an unfamiliar bed, a clinic designed for fixed anatomy, or a crowded hallway. If the design still has a believable answer there—perhaps through shoulder clearance, reaching across the torso without self-collision, and sleeve and jacket construction—the rule is doing real work instead of existing only for spectacle.

If a character breaks the normal version of **Eight-Plus-Arm Builds**, write down what is compensating for the exception and what tradeoff appears somewhere else. The safest fallback is usually a mechanically conservative posture or reduced range, not the anatomy vanishing for no reason. Rarity should still be judged from the whole build. A visually extreme version can remain inside the open tiers, including Mythic, when it does not use creator-reserved founder authority. Unobtanium is not a reward for having the loudest silhouette.

#### Questions worth answering

- How does **Eight-Plus-Arm Builds** affect clothing, furniture, sleep, travel, or personal space?
- What would a Noxivitre medic see about **Eight-Plus-Arm Builds** that an ordinary observer would miss?
- What misconception about **Eight-Plus-Arm Builds** would the character be tired of correcting?
- Which parts of **Eight-Plus-Arm Builds** are automatic, and which can be deliberately controlled?

#### Character-facing note

**Eight-Plus-Arm Builds** can shape habits, accessibility needs, confidence, embarrassment, fashion, or body language, but it should not replace the character's personality. Noxivitres can have extremely different bodies without those bodies deciding morality, intelligence, social importance, or fighting ability. That separation is important to the open-species side of the canon.
